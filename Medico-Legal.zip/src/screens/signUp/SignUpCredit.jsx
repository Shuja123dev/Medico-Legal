import React from 'react'

const SignUpCredit = () => {
  return (
    <div>SignUpCredit</div>
  )
}

export default SignUpCredit