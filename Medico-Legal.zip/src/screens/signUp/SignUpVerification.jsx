import React from 'react'

const SignUpVerification = () => {
  return (
    <div>SignUpVerification</div>
  )
}

export default SignUpVerification