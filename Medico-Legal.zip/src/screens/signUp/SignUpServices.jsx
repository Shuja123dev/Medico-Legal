import React from 'react'

const SignUpServices = () => {
  return (
    <div>SignUpServices</div>
  )
}

export default SignUpServices