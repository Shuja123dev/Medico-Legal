import React from "react";
import "./home.css";

const Home = () => {
  return (
    <div className="expert_home">
      <h1>Expert Panel</h1>
    </div>
  );
};

export default Home;
