import React from 'react'

const CasesTable = () => {
    return (
        <>

        </>
    )
}

export default CasesTable
