
export const FaqData = [
    {
        "question": "Lorem ipsum dolor sit amet, consectetur adipiscing elit ?",
        "answer":"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec a diam lectus. Sed sit amet ipsum mauris. Maecenas congue ligula ac quam viverra nec consectetur ante hendrerit."
    },
    {
        "question": "Lorem ipsum dolor sit amet, consectetur adipiscing elit ?",
        "answer":"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec a diam lectus. Sed sit amet ipsum mauris. Maecenas congue ligula ac quam viverra nec consectetur ante hendrerit."
    },
    {
        "question": "Lorem ipsum dolor sit amet, consectetur adipiscing elit ?",
        "answer":"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec a diam lectus. Sed sit amet ipsum mauris. Maecenas congue ligula ac quam viverra nec consectetur ante hendrerit."
    },
    {
        "question": "Lorem ipsum dolor sit amet, consectetur adipiscing elit ?",
        "answer":"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec a diam lectus. Sed sit amet ipsum mauris. Maecenas congue ligula ac quam viverra nec consectetur ante hendrerit."
    }
]